#include "transaction_manager.h"
#include <iostream>

void TransactionManager::displayAll() {
    std::cout << ">>> Display All function\n";
}